
data = calibracion(10, 'y');






